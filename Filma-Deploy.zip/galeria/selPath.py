SELENIUM_DIRS = r'C:\Users\renat\Downloads\chromedriver_win32'
